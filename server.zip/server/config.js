// server/config.js
module.exports = {
    mongoURI: 'mongodb://localhost:27017/2025SS-TeamRot-TravelPlanner',  // change mongo:27017 to localhost:27017 when testing
    jwtSecret: 'hello'
};